package plc.project.analyzer;

import plc.project.parser.Ast;
import plc.project.parser.Parser;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Set;

public final class Analyzer implements Ast.Visitor<Ir, AnalyzeException> {

    private Scope scope;

    public Analyzer(Scope scope) {
        this.scope = scope;
    }

    public Scope getScope() {
        return scope;
    }

    @Override
    public Ir.Source visit(Ast.Source ast) throws AnalyzeException {
        var statements = new ArrayList<Ir.Stmt>();
        for (var statement : ast.statements()) {
            statements.add(visit(statement));
        }
        return new Ir.Source(statements);
    }

    private Ir.Stmt visit(Ast.Stmt ast) throws AnalyzeException {
        return (Ir.Stmt) visit((Ast) ast); //helper to cast visit(Ast.Stmt) to Ir.Stmt
    }

    @Override
    public Ir.Stmt.Let visit(Ast.Stmt.Let ast) throws AnalyzeException {
        if (scope.resolve(ast.name(), true).isPresent()) {
            throw new AnalyzeException("Redefined variable", Optional.of(ast));
        }
        Type type = null;
        if (ast.type().isPresent()) {
            type = Environment.TYPES.get(ast.type().get());
            if (type == null) {
                throw new AnalyzeException("Undefined type", Optional.of(ast));
            }
        }
        var value = ast.value().isPresent() ? visit(ast.value().get()) : null;
        if (type == null) {
            type = value != null ? value.type() : Type.DYNAMIC;
        }
        scope.define(ast.name(), type);
        return new Ir.Stmt.Let(ast.name(), type, Optional.ofNullable(value));
    }

    @Override
    public Ir.Stmt.Def visit(Ast.Stmt.Def ast) throws AnalyzeException {
        if (scope.resolve(ast.name(), true).isPresent()) {
            throw new AnalyzeException("Redefined variable", Optional.of(ast));
        }
        var original = scope;
        try {
            scope = new Scope(original);
            var parameters = new ArrayList<Ir.Stmt.Def.Parameter>();
            for (int i = 0; i < ast.parameters().size(); i++) {
                var name = ast.parameters().get(i);
                if (scope.resolve(name, true).isPresent()) {
                    throw new AnalyzeException("Duplicate parameter", Optional.of(ast));
                }
                var type = Environment.TYPES.get(ast.parameterTypes().get(i).orElse("Dynamic"));
                if (type == null) {
                    throw new AnalyzeException("Undefined type", Optional.of(ast));
                }
                scope.define(name, type);
                parameters.add(new Ir.Stmt.Def.Parameter(name, type));
            }
            var returns = Environment.TYPES.get(ast.returnType().orElse("Dynamic"));
            if (returns == null) {
                throw new AnalyzeException("Undefined type", Optional.of(ast));
            }
            scope.define("$RETURN", returns);
            var function = new Type.Function(parameters.stream().map(p -> p.type()).toList(), returns);
            original.define(ast.name(), function);
            var body = new ArrayList<Ir.Stmt>();
            for (var stmt : ast.body()) {
                body.add(visit(stmt));
            }
            return new Ir.Stmt.Def(ast.name(), parameters, returns, body);
        } finally {
            scope = original;
        }
    }

    @Override
    public Ir.Stmt.If visit(Ast.Stmt.If ast) throws AnalyzeException {
        var condition = visit(ast.condition());
        if (!condition.type().isSubtypeOf(Type.BOOLEAN)) {
            throw new AnalyzeException("Expected Boolean", Optional.of(ast.condition()));
        }
        var original = scope;
        try {
            scope = new Scope(original);
            var thenBody = new ArrayList<Ir.Stmt>();
            for (var stmt : ast.thenBody()) {
                thenBody.add(visit(stmt));
            }
            scope = new Scope(original);
            var elseBody = new ArrayList<Ir.Stmt>();
            for (var stmt : ast.elseBody()) {
                elseBody.add(visit(stmt));
            }
            return new Ir.Stmt.If(condition, thenBody, elseBody);
        } finally {
            scope = original;
        }
    }

    @Override
    public Ir.Stmt.For visit(Ast.Stmt.For ast) throws AnalyzeException {
        var expression = visit(ast.expression());
        if (!expression.type().isSubtypeOf(Type.ITERABLE)) {
            throw new AnalyzeException("Expected Iterable", Optional.of(ast.expression()));
        }
        var type = Type.INTEGER; //hardcoded
        var original = scope;
        try {
            scope = new Scope(original);
            scope.define(ast.name(), type);
            var body = new ArrayList<Ir.Stmt>();
            for (var stmt : ast.body()) {
                body.add(visit(stmt));
            }
            return new Ir.Stmt.For(ast.name(), type, expression, body);
        } finally {
            scope = original;
        }
    }

    @Override
    public Ir.Stmt.Return visit(Ast.Stmt.Return ast) throws AnalyzeException {
        System.out.println(scope.collect(false));
        var type = scope.resolve("$RETURN", false)
            .orElseThrow(() -> new AnalyzeException("Return outside of function", Optional.of(ast)));
        var value = ast.value().isPresent() ? visit(ast.value().get()) : null;
        if (!(value != null ? value.type() : Type.NIL).isSubtypeOf(type)) {
            throw new AnalyzeException("Expected " + type, Optional.of(value != null ? ast.value().get() : ast));
        }
        return new Ir.Stmt.Return(Optional.ofNullable(value));
    }

    @Override
    public Ir.Stmt.Expression visit(Ast.Stmt.Expression ast) throws AnalyzeException {
        var expression = visit(ast.expression());
        return new Ir.Stmt.Expression(expression);
    }

    @Override
    public Ir.Stmt.Assignment visit(Ast.Stmt.Assignment ast) throws AnalyzeException {
        if (ast.expression() instanceof Ast.Expr.Variable variableAst) {
            var variable = visit(variableAst);
            var value = visit(ast.value());
            if (!value.type().isSubtypeOf(variable.type())) {
                throw new AnalyzeException("Invalid value", Optional.of(ast.value()));
            }
            return new Ir.Stmt.Assignment.Variable(variable, value);
        } else if (ast.expression() instanceof Ast.Expr.Property propertyAst) {
            var property = visit(propertyAst);
            var value = visit(ast.value());
            if (!value.type().isSubtypeOf(property.type())) {
                throw new AnalyzeException("Invalid value", Optional.of(ast.value()));
            }
            return new Ir.Stmt.Assignment.Property(property, value);
        } else {
            throw new AnalyzeException("Invalid assignment expression", Optional.of(ast.expression()));
        }
    }

    private Ir.Expr visit(Ast.Expr ast) throws AnalyzeException {
        return (Ir.Expr) visit((Ast) ast); //helper to cast visit(Ast.Expr) to Ir.Expr
    }

    @Override
    public Ir.Expr.Literal visit(Ast.Expr.Literal ast) throws AnalyzeException {
        var type = switch (ast.value()) {
            case null -> Type.NIL;
            case Boolean _ -> Type.BOOLEAN;
            case BigInteger _ -> Type.INTEGER;
            case BigDecimal _ -> Type.DECIMAL;
            case Character _ -> Type.CHARACTER;
            case String _ -> Type.STRING;
            default -> throw new AssertionError(ast.value().getClass());
        };
        return new Ir.Expr.Literal(ast.value(), type);
    }

    @Override
    public Ir.Expr.Group visit(Ast.Expr.Group ast) throws AnalyzeException {
        var expression = visit(ast.expression());
        return new Ir.Expr.Group(expression);
    }

    @Override
    public Ir.Expr.Binary visit(Ast.Expr.Binary ast) throws AnalyzeException {
        return switch (ast.operator()) {
            case "+" -> {
                var left = visit(ast.left());
                var right = visit(ast.right());
                if (left.type() == Type.DYNAMIC || right.type() == Type.DYNAMIC) {
                    if (left.type() == Type.DYNAMIC && right.type() == Type.DYNAMIC) {
                        yield new Ir.Expr.Binary(ast.operator(), left, right, Type.DYNAMIC);
                    } else if (left.type() == Type.INTEGER || right.type() == Type.INTEGER) {
                        yield new Ir.Expr.Binary(ast.operator(), left, right, Type.INTEGER);
                    } else if (left.type() == Type.DECIMAL || right.type() == Type.DECIMAL) {
                        yield new Ir.Expr.Binary(ast.operator(), left, right, Type.DECIMAL);
                    } else {
                        yield new Ir.Expr.Binary(ast.operator(), left, right, Type.STRING);
                    }
                } else if (left.type().isSubtypeOf(Type.STRING) || right.type().isSubtypeOf(Type.STRING)) {
                    yield new Ir.Expr.Binary(ast.operator(), left, right, Type.STRING);
                } else if (left.type().isSubtypeOf(Type.INTEGER) || left.type().isSubtypeOf(Type.DECIMAL)) {
                    if (!right.type().isSubtypeOf(left.type())) {
                        throw new AnalyzeException("Expected " + left.type(), Optional.of(ast.right()));
                    }
                    yield new Ir.Expr.Binary(ast.operator(), left, right, left.type());
                } else {
                    throw new AnalyzeException("Expected Integer/Decimal (or String)", Optional.of(ast.left()));
                }
            }
            case "-", "*", "/" -> {
                var left = visit(ast.left());
                if (!left.type().isSubtypeOf(Type.INTEGER) && !left.type().isSubtypeOf(Type.DECIMAL)) {
                    throw new AnalyzeException("Expected Integer/Decimal", Optional.of(ast.left()));
                }
                var right = visit(ast.right());
                if (left.type() == Type.DYNAMIC) {
                    if (!right.type().isSubtypeOf(Type.INTEGER) && !right.type().isSubtypeOf(Type.DECIMAL)) {
                        throw new AnalyzeException("Expected Integer/Decimal", Optional.of(ast.right()));
                    }
                } else {
                    if (!right.type().isSubtypeOf(left.type())) {
                        throw new AnalyzeException("Expected " + left.type(), Optional.of(ast.right()));
                    }
                }
                Type type = left.type() != Type.DYNAMIC ? left.type() : right.type();
                yield new Ir.Expr.Binary(ast.operator(), left, right, type);
            }
            case "==", "!=" -> {
                var left = visit(ast.left());
                var right = visit(ast.right());
                if (!left.type().isSubtypeOf(right.type()) && !right.type().isSubtypeOf(left.type())) {
                    throw new AnalyzeException("Expected unifiable type", Optional.of(ast.right()));
                }
                yield new Ir.Expr.Binary(ast.operator(), left, right, Type.BOOLEAN);
            }
            case "<", "<=", ">", ">=" -> {
                var left = visit(ast.left());
                if (!left.type().isSubtypeOf(Type.COMPARABLE)) {
                    throw new AnalyzeException("Expected Comparable", Optional.of(ast.left()));
                }
                var right = visit(ast.right());
                if (!right.type().isSubtypeOf(left.type())) {
                    throw new AnalyzeException("Expected " + left.type(), Optional.of(ast.right()));
                }
                yield new Ir.Expr.Binary(ast.operator(), left, right, Type.BOOLEAN);
            }
            case "AND", "OR" -> {
                var left = visit(ast.left());
                if (!left.type().isSubtypeOf(Type.BOOLEAN)) {
                    throw new AnalyzeException("Expected Boolean", Optional.of(ast.left()));
                }
                var right = visit(ast.right());
                if (!right.type().isSubtypeOf(Type.BOOLEAN)) {
                    throw new AnalyzeException("Expected Boolean", Optional.of(ast.right()));
                }
                yield new Ir.Expr.Binary(ast.operator(), left, right, Type.BOOLEAN);
            }
            default -> throw new AssertionError(ast.operator());
        };
    }

    @Override
    public Ir.Expr.Variable visit(Ast.Expr.Variable ast) throws AnalyzeException {
        var type = scope.resolve(ast.name(), false)
            .orElseThrow(() -> new AnalyzeException("Variable undefined", Optional.of(ast)));
        return new Ir.Expr.Variable(ast.name(), type);
    }

    @Override
    public Ir.Expr.Property visit(Ast.Expr.Property ast) throws AnalyzeException {
        var receiver = visit(ast.receiver());
        if (receiver.type() == Type.DYNAMIC) {
            return new Ir.Expr.Property(receiver, ast.name(), Type.DYNAMIC);
        }
        if (!(receiver.type() instanceof Type.ObjectType object)) {
            throw new AnalyzeException("Invalid property receiver", Optional.of(ast.receiver()));
        }
        var type = resolveProperty(object, ast.name())
            .orElseThrow(() -> new AnalyzeException("Undefined property", Optional.of(ast)));
        return new Ir.Expr.Property(receiver, ast.name(), type);
    }

    @Override
    public Ir.Expr.Function visit(Ast.Expr.Function ast) throws AnalyzeException {
        var type = scope.resolve(ast.name(), false)
            .orElseThrow(() -> new AnalyzeException("Function undefined", Optional.of(ast)));
        if (!(type instanceof Type.Function function)) {
            throw new AnalyzeException("Variable is not a function.", Optional.of(ast));
        }
        if (ast.arguments().size() != function.parameters().size()) {
            throw new AnalyzeException("Invalid arity.", Optional.of(ast));
        }
        var arguments = new ArrayList<Ir.Expr>();
        for (int i = 0; i < ast.arguments().size(); i++) {
            var analyzed = visit(ast.arguments().get(i));
            if (!analyzed.type().isSubtypeOf(function.parameters().get(i))) {
                throw new AnalyzeException("Invalid argument.", Optional.of(ast.arguments().get(i)));
            }
            arguments.add(analyzed);
        }
        return new Ir.Expr.Function(ast.name(), arguments, function.returns());
    }

    @Override
    public Ir.Expr.Method visit(Ast.Expr.Method ast) throws AnalyzeException {
        var receiver = visit(ast.receiver());
        if (receiver.type() == Type.DYNAMIC) {
            var arguments = new ArrayList<Ir.Expr>();
            for (var argument : ast.arguments()) {
                arguments.add(visit(argument));
            }
            return new Ir.Expr.Method(receiver, ast.name(), arguments, Type.DYNAMIC);
        }
        if (!(receiver.type() instanceof Type.ObjectType object)) {
            throw new AnalyzeException("Invalid method receiver", Optional.of(ast.receiver()));
        }
        var type = resolveProperty(object, ast.name())
            .orElseThrow(() -> new AnalyzeException("Undefined method", Optional.of(ast)));
        if (!(type instanceof Type.Function function)) {
            throw new AnalyzeException("Invalid method call", Optional.of(ast.receiver()));
        }
        if (ast.arguments().size() != function.parameters().size()) {
            throw new AnalyzeException("Invalid method arity", Optional.of(ast.receiver()));
        }
        var arguments = new ArrayList<Ir.Expr>();
        for (int i = 0; i < ast.arguments().size(); i++) {
            var argument = visit(ast.arguments().get(i));
            if (!argument.type().isSubtypeOf(function.parameters().get(i))) {
                throw new AnalyzeException("Invalid argument", Optional.of(ast.arguments().get(i)));
            }
            arguments.add(argument);
        }
        return new Ir.Expr.Method(receiver, ast.name(), arguments, function.returns());
    }

    @Override
    public Ir.Expr.ObjectExpr visit(Ast.Expr.ObjectExpr ast) throws AnalyzeException {
        var object = new Type.ObjectType(ast.name(), new Scope(null));
        var fields = new ArrayList<Ir.Stmt.Let>();
        for (var field : ast.fields()) {
            if (object.scope().resolve(field.name(), true).isPresent()) {
                throw new AnalyzeException("Redefined field", Optional.of(field));
            }
            Type type = null;
            if (field.type().isPresent()) {
                type = Environment.TYPES.get(field.type().get());
                if (type == null) {
                    throw new AnalyzeException("Undefined type", Optional.of(field));
                }
            }
            var value = field.value().isPresent() ? visit(field.value().get()) : null;
            if (type == null) {
                type = value != null ? value.type() : Type.DYNAMIC;
            }
            object.scope().define(field.name(), type);
            fields.add(new Ir.Stmt.Let(field.name(), type, Optional.ofNullable(value)));
        }
        var methods = new ArrayList<Ir.Stmt.Def>();
        for (var method : ast.methods()) {
            if (object.scope().resolve(method.name(), true).isPresent()) {
                throw new AnalyzeException("Redefined method", Optional.of(method));
            }
            var original = scope;
            try {
                scope = new Scope(original);
                scope.define("this", object);
                var parameters = new ArrayList<Ir.Stmt.Def.Parameter>();
                for (int i = 0; i < method.parameters().size(); i++) {
                    var name = method.parameters().get(i);
                    if (scope.resolve(name, true).isPresent()) {
                        throw new AnalyzeException("Duplicate parameter", Optional.of(method));
                    }
                    var type = Environment.TYPES.get(method.parameterTypes().get(i).orElse("Dynamic"));
                    if (type == null) {
                        throw new AnalyzeException("Undefined type", Optional.of(method));
                    }
                    scope.define(name, type);
                    parameters.add(new Ir.Stmt.Def.Parameter(name, type));
                }
                var returns = Environment.TYPES.get(method.returnType().orElse("Dynamic"));
                if (returns == null) {
                    throw new AnalyzeException("Undefined type", Optional.of(method));
                }
                scope.define("$RETURN", returns);
                var function = new Type.Function(parameters.stream().map(p -> p.type()).toList(), returns);
                object.scope().define(method.name(), function);
                var body = new ArrayList<Ir.Stmt>();
                for (var stmt : method.body()) {
                    body.add(visit(stmt));
                }
                methods.add(new Ir.Stmt.Def(method.name(), parameters, returns, body));
            } finally {
                scope = original;
            }
        }
        return new Ir.Expr.ObjectExpr(ast.name(), fields, methods, object);
    }

    private static Optional<Type> resolveProperty(Type.ObjectType object, String name) {
        return object.scope().resolve(name, false).or(() -> {
            var prototype = object.scope().resolve("prototype", false).orElse(null);
            if (prototype == Type.DYNAMIC) {
                return Optional.of(Type.DYNAMIC);
            } else if (prototype instanceof Type.ObjectType o) {
                return resolveProperty(o, name);
            }
            return Optional.empty();
        });
    }

}
